'''
lib-anim API
'''

from .window import window
from .time import time
from .colormap import colormap

from . import plane

from .information import information