'''
animate API
'''

from .window import window
from .time import time
from .colormap import colormap

from .plane import *

from .information import information