# animate
A python toolbox for creating animations.

## Installation

```
pip install animate
```

## Dependencies

Depends on `numpy`, `matplotlib`, `pyqt6` and `imageio[ffmpeg]`
